## Notes for Testing 
Permission for Accelerometer Data with Secure https:// Protocol only 
therefore network connection from phone to  localhost 127.0.01 wont work
For Demo check on https://editor.p5js.org/hzuellig/full/kkr-zruko 
or install a https connection to localhost with node, Tutorial below 
Basic knowledge of http is required
https://akshitb.medium.com/how-to-run-https-on-localhost-a-step-by-step-guide-c61fde893771 