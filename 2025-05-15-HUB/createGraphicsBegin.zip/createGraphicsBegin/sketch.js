
/**
 * Workshop Kinetic Typography with p5.js
 * © HSLU, 2025, Hanna Zuellig
 * Example inspired by: https://timrodenbroeker.de/processing-tutorial-kinetic-typography-1/
 * and https://openprocessing.org/sketch/2351903
 */

let font;
let pg;
let scaleFactor=2;
let tileW;
let tileH;


let params = {
  text: "Corruption",
  size: 240,
  tilesX:15,
  tilesY:15,
  triggerStop: startStop,
  triggerAction: exportPNG
};

let isLooping=true;

function preload() {
  font = loadFont("fonts/BiancoSansNewExtraBold.otf");
}

function setup() {
  pixelDensity(1);
  createCanvas(windowWidth, windowHeight);
  pg = createGraphics(windowWidth/scaleFactor, windowHeight/scaleFactor);

  // Setup GUI
  const gui = new dat.GUI();
  gui.add(params, 'text').name('Text Input').onFinishChange(init);
  gui.add(params, 'size', 100, 500).name('Text Size').onFinishChange(init);
  gui.add(params, 'tilesX', 3, 30).name('Anzahl Spalten');
  gui.add(params, 'tilesY', 3, 30).name('Anzahl Zeilen');
  gui.add(params, 'triggerStop').name("Start/Stop"); // ✅ This creates a button
  gui.add(params, 'triggerAction').name("Export Image"); // ✅ This creates a button

  init();

  //frameRate(6)
}

function draw() {
  background(0);


  image(pg, 0, 0, pg.width*scaleFactor, pg.height*scaleFactor);

  
}




function init(){
  // PGraphics

  pg.blendMode(SCREEN)
  pg.background(0);
  pg.push();
  pg.translate(pg.width/2, pg.height/2);
  pg.textAlign(CENTER, CENTER);

  pg.fill(255, 0, 0, 200);
  pg.textFont(font);
  pg.textSize(params.size/scaleFactor); 
  pg.text(params.text, 0, 0);

  pg.fill(0, 255, 0, 200);
  pg.textFont(font);
  pg.textSize(params.size/scaleFactor-2); 
  pg.text(params.text, 0, 0);

  pg.fill(0, 0, 255, 200);
  pg.textFont(font);
  pg.textSize(params.size/scaleFactor+2); 
  pg.text(params.text, 0, 0);

  pg.pop();

  
}

function startStop(){
  if (isLooping){
    noLoop();
    isLooping=false;
  } else {
    loop();
    isLooping=true;
  }
}


function exportPNG() {
  let d = new Date();
  /* ~~~~~~~~~~~~ export PNG */
  save(d + ".png")
  noLoop();
}