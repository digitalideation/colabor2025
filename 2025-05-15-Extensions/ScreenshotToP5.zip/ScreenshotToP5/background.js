let imageSend;

// Optional: eigene Fehlerbehandlung
function onError(error) {
    console.error(`Error: ${error}`);
}

// Hauptfunktion für Button-Klick
browser.browserAction.onClicked.addListener(async () => {
    try {
        // 1. Screenshot der aktuellen Seite
        imageSend = await browser.tabs.captureTab();

        // 2. Aktiven Tab abfragen
        const [activeTab] = await browser.tabs.query({
            currentWindow: true,
            active: true
        });

        // 3. Nachricht an aktiven Tab senden
        if (activeTab?.id) {
            await browser.tabs.sendMessage(activeTab.id, { data: imageSend });
        } else {
            console.warn("Kein aktiver Tab gefunden.");
        }

    } catch (error) {
        onError(error);
    }
});
