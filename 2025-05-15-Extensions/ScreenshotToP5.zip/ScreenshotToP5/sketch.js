"use strict";
/**
 * HSLU 2025, Hanna Zuellig
 * licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
 * +Colabor Creative Coding Boilerplate
 * Exmaple boilerplate for using p5.js with a browser extension
 * This example uses the p5.js library to create a canvas and draw a screenshot on it.
 */

let head = document.getElementsByTagName('head')[0];
let link = document.createElement('link');
link.rel = 'stylesheet';
link.type = 'text/css';
link.href = browser.runtime.getURL("canvas.css");
link.media = 'all';
head.appendChild(link);

let screenshot;
let scale=1;
browser.runtime.onMessage.addListener((request) => {
    screenshot = request.data;

    //create a new p5 instance when the screenshot is received
    //this is necessary because the p5 instance needs to be created in the same context as the screenshot
    let myp5 = new p5(s);

    //console.log("screenshot received");

});

let s = function (sketch) {
    let source;


    sketch.preload = function () {
        source = sketch.loadImage(screenshot);

    }
    sketch.setup = function () {
        sketch.pixelDensity(1);//we create a rendering context with a pixel density of 1
        //this needs less memory and is faster
        let c = sketch.createCanvas(window.innerWidth, window.innerHeight);

        //our source has maybe another pixel density
        //we find this out and store the relation int the variable scale

        scale=source.width/sketch.width;


        c.position(0, 0);
        c.style('z-index', 200);



        //you need to wait until the image is loaded
        if (typeof source === 'object') {

            //here we use the scale variable to resize the source image to the size of the canvas
            //source.resize(source.width * scale, source.height * scale);
            sketch.image(source, 0, 0, sketch.width , sketch.height );
            

        }

    }

    sketch.draw = function () {
        //you need to wait until the image is loaded
        if (typeof source === 'object') {

            //here you can add your own code to manipulate the image
            // for example copy parts around the mouse and display them in a different place
            //remember that the source might be bigger than the canvas
            // that is why we use the scale variable to resize the copied part
            let randomOffset = 5;
            sketch.copy(source, sketch.mouseX*scale, sketch.mouseY*scale, 100*scale, 100*scale, sketch.mouseX + randomOffset, sketch.mouseY + randomOffset, 100, 100);


        }


    }

}