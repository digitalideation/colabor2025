On firefox, goto about:debugging#/runtime/this-firefox

* HSLU 2025, Hanna Zuellig, +Colabor Creative Coding Boilerplate
* licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.

* Exmaple boilerplate for using p5.js with a browser extension
* This example uses the p5.js library to create a canvas and draw a screenshot on it.
